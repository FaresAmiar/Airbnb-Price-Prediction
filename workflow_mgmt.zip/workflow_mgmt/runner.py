from prefect import task, Flow
from .data_ops import load_dataset, preprocess_dataset, split_dataset, transform_dataset
from .model_ops import train_regression_model, evaluate_regression_model

@task
def load_task():
    return load_dataset("./data/AB_NYC_2019.csv")

@task
def preprocess_task(data):
    return preprocess_dataset(data)

@task
def split_task(data):
    return split_dataset(data)

@task
def transform_task(train, test):
    return transform_dataset(train, test)

@task
def train_task(X_train, y_train):
    return train_regression_model(X_train, y_train)

@task
def evaluate_task(model, X_test, y_test):
    return evaluate_regression_model(model, X_test, y_test)

with Flow("Airbnb Price Prediction") as flow:
    data = load_task()
    processed_data = preprocess_task(data)
    train, test = split_task(processed_data)
    X_train, y_train, X_test, y_test = transform_task(train, test)
    model = train_task(X_train, y_train)
    rmse = evaluate_task(model, X_test, y_test)
    flow.run()
