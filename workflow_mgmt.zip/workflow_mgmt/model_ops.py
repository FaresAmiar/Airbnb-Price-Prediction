from sklearn.linear_model import Ridge
from sklearn.metrics import mean_squared_error
import numpy as np

def train_regression_model(X: np.array, y: np.array):
    """Train a regression model."""
    model = Ridge(alpha=0.1)
    model.fit(X, y)
    return model

# 6. Evaluate Model
def evaluate_regression_model(model, X: np.array, y: np.array):
    """Evaluate the regression model and return RMSE."""
    y_pred = model.predict(X)
    rmse = np.sqrt(mean_squared_error(y, y_pred))
    return rmse